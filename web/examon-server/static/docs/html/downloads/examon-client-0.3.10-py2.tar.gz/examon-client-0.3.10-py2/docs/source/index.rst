.. Examon documentation master file, created by
   sphinx-quickstart on Tue Aug 27 02:36:02 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Examon's documentation!
==================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   intro
   libref



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
