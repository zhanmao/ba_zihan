# Examon-cli

Command line utility to use Examon 

```bash
Usage: examon-cli [OPTIONS] COMMAND [ARGS]...

  ExaMon Command Line Interface

Options:
  -p TEXT    Examon server port  [required]
  -H TEXT    Examon server address  [required]
  -P TEXT    Examon password  [required]
  -U TEXT    Examon username  [required]
  --version  Show the version and exit.
  --help     Show this message and exit.

Commands:
  energy  Return the total energy consumption of a job.
  shell   Start an interactive shell for ExaMon commands.
```





