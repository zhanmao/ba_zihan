import os
import time
from examon.examon import Examon, ExamonQL


### DB Host data
# KairosDB server IP
KAIROSDB_SERVER = '130.186.16.81'
# KairosDB server port
KAIROSDB_PORT = '3000'
# DB username
USER = ''
# DB password
PWD = ''

### Query info. Full reference: https://kairosdb.github.io/docs/build/html/restapi/QueryMetrics.html
# Metrics list
# List of metrics to query. Wildcards: '*' to selects all metrics 
METRICS = ['*']
# Time of the first data point 
TSTART = "17-11-2019 00:00:00"
# Time of the last data point
TSTOP = "18-11-2019 00:00:00"
# Time zone
TIME_ZONE = 'Europe/Rome'
# Path of directory where to save metrics
FILE_NAME = 'Backup_Davide'

### Buffered queries
# Chunk size per metric in ms.
# Set this parameter to automatically slice the main query in sub-queries of
# BUFSIZE milliseconds. This prevents to saturate your client memory.  
BUFSIZE = 320000
# Output file compression.
# Generated file are compressed.
# Valid options are: None, 'gzip', 'bz2'
COMP = 'gzip'


if __name__ == '__main__':

    if USER == '':
        print("KairosDB Login:")
        USER = input("username: ")
    if PWD == '':
        PWD = input("password: ")

    ex = Examon(KAIROSDB_SERVER, port=KAIROSDB_PORT, user=USER, password=PWD, verbose=False, proxy=True)
    sq = ExamonQL(ex)

    if METRICS == ['*']:
        metric_names = ex.query_metricsnames()['results']
    else:
        metric_names = METRICS
    print("Total Metrics: %d" % len(metric_names))    
    
    outdir = './' + FILE_NAME + '_from_' + TSTART.replace(' ','_').replace(':','') + '_to_' + TSTOP.replace(' ','_').replace(':','')
    if not os.path.exists(outdir):
        os.mkdir(outdir)

    compression = {None: '.csv', 
            'gzip': '.csv.gz', 
            'bz2': '.csv.bz'}

    t0 = time.time()    
    for metric in metric_names:
        t0_q = time.time()
        
        df = sq.SELECT('*') \
            .FROM(metric) \
            .WHERE(org='e4') \
            .TSTART(TSTART) \
            .TSTOP(TSTOP) \
            .execute_async(n_workers=4, threads_per_worker=2, processes=True, batch_size=BUFSIZE, dashboard_address=':4040', 
                         interface='eth0', memory_limit='0')

        print("Saving...")
        df['timestamp'] = df['timestamp'].astype('int64', copy=False)
        pathname = os.path.join(outdir, metric + compression[COMP]) 
        if not os.path.isfile(pathname):
            df.to_csv(pathname, sep=';', decimal='.', float_format='%.12f', index=False, header ='column_names', compression=COMP)
        else: 
            df.to_csv(pathname, sep=';', decimal='.', float_format='%.12f', index=False, mode = 'a', header=False, compression=COMP)
        print("Query time: %fs" % (time.time() - t0_q))
        del df
    print("Done! - Total time: %fs" % (time.time() - t0))