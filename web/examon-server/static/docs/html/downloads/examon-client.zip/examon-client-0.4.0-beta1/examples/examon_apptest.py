# -*- coding: utf-8 -*-
"""
    Examon app example
    
    Created on Tue Jun 20 18:03:25 2017
    
    @author:francesco.beneventi@unibo.it

"""

from examon.examon import Examon

KAIROSDB_SERVER = '130.186.13.80'
KAIROSDB_PORT = '8010'

USER = ''
PWD = ''


if __name__ == '__main__':

    if USER == '':
        print("KairosDB Login:")
        USER = input("username: ")
    if PWD == '':
        PWD = input("password: ")
        
    # some metrics
    core_metrics = ['AVX.ALL',
          'C3',
          'C3res',
          'C6',
          'C6res',
          'CYCLE_ACTIVITY.STALLS_L2_PENDING',
          'CYCLE_ACTIVITY.STALLS_LDM_PENDING',
          'IDQ_UOPS_NOT_DELIVERED.CORE',
          'INT_MISC.RECOVERY_CYCLES',
          'MEM_LOAD_UOPS_RETIRED.L3_MISS',
          'UOPS_ISSUED.ANY',
          'UOPS_RETIRED.RETIRE_SLOTS',
          'aperf',
          'clk_curr',
          'clk_ref',
          'cpi',
          'dT_core',
          'freq',
          'hsw_ep::INT_MISC:RECOVERY_CYCLES',
          'instr',
          'ips',
          'load_core',
          'mperf',
          'temp',
          'tsc'] 
    
    core_metrics_basic = ['AVX.ALL',
          'C3',
          'C6',
          'CYCLE_ACTIVITY.STALLS_L2_PENDING',
          'CYCLE_ACTIVITY.STALLS_LDM_PENDING',
          'IDQ_UOPS_NOT_DELIVERED.CORE',
          'INT_MISC.RECOVERY_CYCLES',
          'MEM_LOAD_UOPS_RETIRED.L3_MISS',
          'UOPS_ISSUED.ANY',
          'UOPS_RETIRED.RETIRE_SLOTS',
          'aperf',
          'clk_curr',
          'clk_ref',
          'hsw_ep::INT_MISC:RECOVERY_CYCLES',
          'instr',
          'mperf',
          'temp',
          'tsc'] 
    
    core_metrics_der = [
          'C3res',
          'C6res',
          'cpi',
          'freq',
          'ips',
          'load_core'] 
    
    
    core_metrics_counters = ['AVX.ALL',
          'CYCLE_ACTIVITY.STALLS_L2_PENDING',
          'CYCLE_ACTIVITY.STALLS_LDM_PENDING',
          'IDQ_UOPS_NOT_DELIVERED.CORE',
          'INT_MISC.RECOVERY_CYCLES',
          'MEM_LOAD_UOPS_RETIRED.L3_MISS',
          'UOPS_ISSUED.ANY',
          'UOPS_RETIRED.RETIRE_SLOTS'] 
    
    cpu_metrics = [  'dT_cpu',
          'erg_dram',
          'erg_pkg',
          'erg_units',
          'freq_ref',
          'pow_dram',
          'pow_pkg',
          'temp_pkg',
          'tsc',
          'uclk']
    
    
    cpu_in = [
          'pow_dram',
          'pow_pkg']

    # create an examon instance
    ex = Examon(KAIROSDB_SERVER, port=KAIROSDB_PORT, user=USER, password=PWD)
    
    # test node
    node = ['node061']

    # time slice (absolute)
    tstart = "10-10-2017 17:09:00"   
    tstop = "10-10-2017 21:10:00"
    
    # time slice (relative)
#    tstart = [1200,'minutes']   
#    tstop = None               
    
    # get core metrics
    metrics = ['temp']
    tags = {'org': ['cineca'], 'cluster': ['galileo'], 'plugin' : ['pmu_pub'], 'node': node, 'core':[str(i) for i in range(0,16)] }
    groupby = {'name':'tag', 'tags':['node','core']}
    aggrby = None
    core_count_series = ex.query(tstart, tstop, metrics, tags, groupby=groupby, aggrby=aggrby)
    core_count_series.to_series(flat_index=True)
    
    # get cpu metrics
    metrics = ['pow_pkg']
    tags = {'org': ['cineca'], 'cluster': ['galileo'], 'plugin' : ['pmu_pub'], 'node': node, 'cpu':[str(i) for i in range(0,2)] }
    groupby = {'name':'tag', 'tags':['node','cpu']}
    aggrby = None
    cpu_count_series = ex.query(tstart, tstop, metrics, tags, groupby=groupby, aggrby=aggrby)
    cpu_count_series.to_series(flat_index=True)
    
    # get IPMI metrics
    metrics = ['Avg_Power']
    tags = {'org': ['cineca'], 'cluster': ['galileo'], 'plugin' : ['ipmi_pub'], 'node':node }
    groupby = {'name':'tag', 'tags':['node']}
    aggrby = None
    ipmi_series = ex.query(tstart, tstop, metrics, tags, groupby=groupby, aggrby=aggrby)
    ipmi_series.to_series(flat_index=True)
    
    # get room metrics
    metrics = ['temp']
    tags = {'org': ['cineca'],  'room' : ['n']}
    groupby = {'name':'tag', 'tags':['sensorid','plugin']}
    aggrby = None
    room_series = ex.query(tstart, tstop, metrics, tags, groupby=groupby, aggrby=aggrby)
    room_series.to_series(flat_index=True)   
    
    # merge all metrics to df_ts format only
    data = ex.merge([core_count_series.df_ts, ipmi_series.df_ts, room_series.df_ts, cpu_count_series.df_ts], interp='time', dropna=True)
    
    # populate also df_table format 
    data.merge([core_count_series.df_table, ipmi_series.df_table, room_series.df_table, cpu_count_series.df_table])
      
    # time series preview
    data.df_ts.head
    
    # plot series
    data.df_ts \
        .interpolate(method='time') \
        .plot(marker='.') \
        .legend(loc='center left', bbox_to_anchor=(1, 0.5))
        
    # export to csv as time series
    data.to_csv('examon_metrics_ts.csv', epoch=True, decimal=',', shape='ts')
    
    # export to csv as table
    data.to_csv('examon_metrics_table.csv', epoch=True, decimal=',', shape='table')
    