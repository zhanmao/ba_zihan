#!/usr/bin/env python
#
#   examon_cli.py
#
#   Author: Francesco Beneventi
#
#   16/03/2022
#

import json
import click
from prompt_toolkit import PromptSession

from api.examon_api import get_energy_by_job_id
from examon_cli.version import __version__


config = {
    'username': '',
    'password': '',
    'server_ip': '',
    'port': ''
}

@click.version_option(version=__version__, prog_name='examon-cli')
@click.option('-U', 'username', help='Examon username', required=True)
@click.option('-P', 'password', help='Examon password', required=True)
@click.option('-H', 'server_ip', help='Examon server address', required=True)
@click.option('-p', 'port', help='Examon server port', required=True)
@click.group()
def cli(username, password, server_ip, port):
    """
    ExaMon Command Line Interface
    \f

    Args:
        username (str): The username for Examon.
        password (str): The password for Examon.
        server_ip (str): The server IP address for Examon.
        port (str): The server port for Examon.

    Returns:
        None
    """
    config['username'] = username.strip()
    config['password'] = password.strip()
    config['server_ip'] = server_ip.strip()
    config['port'] = port.strip()
    
    return

@cli.command()
@click.option('--job_id', type=int, help='The id of the job', required=True)
@click.option('--user_id', type=str, help='The user id of the job owner', required=False)
def energy(job_id=None, user_id=None):
    """
    Return the total energy consumption of a job.
    \f

    Args:
        job_id (int): The id of the job.
        user_id (str): The user id of the job owner (optional,  Future feature).

    Example:
        examon-cli.py energy --job_id 123
    """
    if job_id is None and user_id is None:
        click.echo("Either job_id or user_id must be provided")
        return
    elif job_id is not None and user_id is not None:
        click.echo("Not Implemented")
        return
    elif job_id is not None:
        ret = get_energy_by_job_id(config['server_ip'], config['port'], config['username'], config['password'], job_id)
        if ret:
            click.echo(json.dumps(ret, indent=4)) 
        return
    elif user_id is not None:
        click.echo("Not Implemented")
        return
    else:
        click.echo("Invalid arguments")
    


@cli.command()
def shell():
    """
    Start an interactive shell for ExaMon commands.
    \f
    """
    session = PromptSession()

    while True:
        user_input = session.prompt('examon> ')
        if user_input.strip() == 'exit':
            break
        else:
            click.echo("Command not recognized. Type 'exit' to quit.")

if __name__ == '__main__':
    cli()
